﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;


namespace SharePointCSOMExample
{
    class Program
    {
        static void Main(string[] args)
        {
            ClientContext context = new ClientContext("http://sp16-app-beta/sites/PritinTest/"); //creates an instance of ClientContext called context
            context.Credentials = CredentialCache.DefaultCredentials; // gets the credentials of the logged in user
            Web site = context.Web; //creates an instance of the "Web" object called "site" gets the properties of the website as defined by context

            context.Load(site, x => x.Title, y => y.Language); // retrieves the  Title property of the "site" object from the server
            //context.Load(site);
            context.ExecuteQuery(); //Executes the query
            Console.WriteLine("Site Title: " + site.Title);
            Console.WriteLine("Site Language: " + site.Language);

            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }
    }
}
